import AddNotesForm from '@/Components/AddNotesForm';
import NavBarAddNotes from '@/Components/NavBarAddNotes';
export default function addNotes(){
    return(
    <>
    <NavBarAddNotes/>
    <AddNotesForm/>
    </>);
}