import { useContext } from "react";
import { UserContext } from "@/Lib/UserContext";
import { googleAuthProvider } from "@/Lib/Firebase";
import {auth} from '@/Lib/Firebase'

export default function Login(){
    const { user } = useContext(UserContext);
    const googleSignIn = async () => {
        await auth.signInWithPopup(googleAuthProvider);
    }
    const googleSignOut = async () => {
        await auth.signOut();
    }

    return(
        user ?
        <button onClick={googleSignOut} className="btn btn-light">Sign out { user.email}</button>
        :
        <button onClick={googleSignIn} className="btn btn-light">Sign In</button>
    );
}